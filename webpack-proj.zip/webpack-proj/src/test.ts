function example(){
    console.log("Hello")
}

export {example};